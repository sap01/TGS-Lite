
# convert a set of arcs to a (real) adjacency matrix.
arcs2amat = function(arcs, nodes) {

  .Call(call_arcs2amat,
        arcs = as.character(arcs),
        nodes = as.character(nodes))

}#ARCS2AMAT

# convert an adjacency matrix back to a set of arcs.
amat2arcs = function(a, nodes) {

  .Call(call_amat2arcs,
        amat = a,
        nodes = nodes)

}#AMAT2ARCS

