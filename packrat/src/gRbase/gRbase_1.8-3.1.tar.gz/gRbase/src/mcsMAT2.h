
#ifndef MCSMAT2_H
#define MCSMAT2_H

#include <Rcpp.h>
using namespace Rcpp;

SEXP mcsMAT0_ ( SEXP XX_, SEXP mcs0idx_=R_NilValue );

#endif
